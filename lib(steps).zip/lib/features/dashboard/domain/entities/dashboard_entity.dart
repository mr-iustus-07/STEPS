class DashboardEntity {
  const DashboardEntity();
}

