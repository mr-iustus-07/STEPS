class DashboardModel {
  const DashboardModel();
}

