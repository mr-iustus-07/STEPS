class RoutineLocalDatasource {
  const RoutineLocalDatasource();
}

